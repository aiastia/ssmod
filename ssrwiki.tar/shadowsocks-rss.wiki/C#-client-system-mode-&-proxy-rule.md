## 区别如图

![](https://cloud.githubusercontent.com/assets/8436963/22097160/930b8240-de5a-11e6-9819-7cbccbd1be34.png)

简单的来说，“系统代理模式”只是一个附属工具，用于修改系统代理设置，其设置和SSR本身没有任何关系

代理规则是SSR内部的工具，用来对进入SSR的流量进行分流的规则