# ShadowsocksR #

BitTorrent Sync：BHS55LP54SO7A434QBB5Z2O6B7A45B2BX  
主页：[https://breakwa11.github.io/](https://breakwa11.github.io/)  
Wiki：[https://github.com/breakwa11/shadowsocks-rss/wiki](https://github.com/breakwa11/shadowsocks-rss/wiki)  
ZeroNet主页：[shadowsocksr.bit](http://127.0.0.1:43110/shadowsocksr.bit)  
ShadowsocksR主要分支：[SSR C#](https://github.com/shadowsocksr/shadowsocksr-csharp), [SSR python manyuser](https://github.com/shadowsocksr/shadowsocksr/tree/manyuser), [SSR-libev](https://github.com/shadowsocksr/shadowsocksr-libev)  
Android APP: [SSR-android](https://github.com/shadowsocksr/shadowsocksr-android/releases)  
iOS APP： [Shadowrocket](https://itunes.apple.com/us/app/shadowrocket/id932747118), [Potatso2](https://download.potatso.com), [Cross](https://itunes.apple.com/cn/app/cross-shadowsocks-proxy-client/id1194595243),[Wingy](https://itunes.apple.com/cn/app/wingy-http-s-socks5-proxy-utility/id1178584911?l=en&mt=8)  
MAC APP：[ShadowsocksX-NG](https://github.com/qinyuhang/ShadowsocksX-NG/releases), [ShadowsocksX-R](https://github.com/yichengchen/ShadowsocksX-R/releases)  
其它跨平台分支：[avege](https://github.com/avege/avege), [electron-ssr](https://github.com/erguotou520/electron-ssr)  
Docker: [https://hub.docker.com/r/breakwa11/shadowsocksr/](https://hub.docker.com/r/breakwa11/shadowsocksr/)  
发布链接：[https://github.com/breakwa11/shadowsocks-rss](https://github.com/breakwa11/shadowsocks-rss)  
服务端配置教程：[单用户教程](https://github.com/breakwa11/shadowsocks-rss/wiki/Server-Setup) 
[数据库多用户教程](https://github.com/breakwa11/shadowsocks-rss/wiki/Server-Setup(manyuser-with-mysql))  
[json版多用户教程](https://github.com/breakwa11/shadowsocks-rss/wiki/Server-Setup(manyuser-with-mudbjson))（仅一台服务器适用）
